#ifndef UTIL_HPP
#define UTIL_HPP

#include<iostream>

/**
 * This is a utility file that stores some helper functions for the 
 * complete kit
 */
void implMe();

#endif //UTIL_HPP defined
